<?php

# Get layout menu
echo $this->Layout->menu('main');

# Get sidebar
echo $this->Layout->blocks('right');

?>